﻿namespace EP.Conference.Models.Speakers
{
    public class ExtendedSpeakersField : SpeakerFields
    {
        public string Etag { get; set; }
    }
}
