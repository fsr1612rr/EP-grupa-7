﻿namespace EP.Conference.Settings
{
    public class HttpSettings
    {
        public string Url { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string ProductKey { get; set; }
    }
}
